// ===============================
// Burger Spot Shopping Cart
// ===============================


let cart = JSON.parse(localStorage.getItem("cart")) || [];


// ===============================
// Add Item To Cart
// ===============================

function addToCart(name, price) {

    let existingItem = cart.find(
        item => item.name === name
    );


    if(existingItem){

        existingItem.quantity += 1;

    } else {

        cart.push({

            name: name,
            price: price,
            quantity: 1

        });

    }


    saveCart();

    updateCart();

}



// ===============================
// Remove Item
// ===============================

function removeFromCart(index){

    cart.splice(index,1);

    saveCart();

    updateCart();

}



// ===============================
// Save Cart
// ===============================

function saveCart(){

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

}



// ===============================
// Display Cart
// ===============================

function updateCart(){

    let cartBox = document.getElementById(
        "cartItems"
    );


    let totalBox = document.getElementById(
        "cartTotal"
    );


    if(!cartBox) return;


    cartBox.innerHTML = "";

    let total = 0;


    cart.forEach((item,index)=>{


        let itemTotal =
        item.price * item.quantity;


        total += itemTotal;


        cartBox.innerHTML += `

        <div class="cart-item">

            <p>
            ${item.name}
            x ${item.quantity}
            = Rs. ${itemTotal}
            </p>


            <button onclick="
            removeFromCart(${index})
            ">
            Remove
            </button>

        </div>

        `;


    });


    totalBox.innerHTML =
    "Total: Rs. " + total;


}



// Load Cart When Page Opens

document.addEventListener(
"DOMContentLoaded",
updateCart
);