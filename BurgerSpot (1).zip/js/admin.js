// ===============================
// Burger Spot Admin Login
// ===============================


function login(){


    let username =
    document.getElementById("username").value;


    let password =
    document.getElementById("password").value;



    // Demo Admin Login
    // Change these later

    if(
        username === "bs97" &&
        password === "Admin123@1"
    ){

        localStorage.setItem(
            "adminLogin",
            "true"
        );


        window.location.href =
        "index.html";


    }

    else{

        alert(
        "Invalid Username or Password"
        );

    }

}



// ===============================
// Check Admin Session
// ===============================

function checkAdmin(){


    let login =
    localStorage.getItem(
        "adminLogin"
    );


    if(login !== "true"){

        window.location.href =
        "login.html";

    }

}