let settings =

JSON.parse(localStorage.getItem("settings")) || {

restaurantName:"Burger Spot",

deliveryTime:"30-40 Minutes",

open:true

};

let products =
JSON.parse(localStorage.getItem("products")) || [];


let menu =
document.getElementById("product-list");



function showProducts(){


menu.innerHTML += `

<div class="product-card">

<img src="${product.image || 'images/logo.png'}">

<div class="badges">

${product.bestseller ? '<span class="badge bestseller">⭐ Bestseller</span>' : ''}

${product.newItem ? '<span class="badge new">🆕 New</span>' : ''}

${product.recommended ? '<span class="badge recommend">👍 Recommended</span>' : ''}

</div>

<h3>${product.name}</h3>

<p>${product.description}</p>

<p>

${product.spicy ? '🌶️ Spicy' : ''}

${product.veg ? '🥬 Veg' : ''}

${product.nonVeg ? '🍗 Non-Veg' : ''}

</p>

<p>
⏱️ ${product.prepTime || 20} min
</p>

<p>

<del>Rs.${product.price}</del>

</p>

<p class="price">

Rs.${product.finalPrice}

</p>

<button class="add-btn"

onclick="openProduct(${product.id})">

+ Add

</button>

</div>

`;
function loadAccountMenu(){

let menu =
document.getElementById("accountMenu");

if(!menu) return;

let loggedIn =
localStorage.getItem("customerLogin");

if(loggedIn==="true"){

let customer =
JSON.parse(localStorage.getItem("currentCustomer"));

menu.innerHTML = `

<span>👋 ${customer.name}</span>

<a href="profile.html" class="add-btn">
My Account
</a>

`;

}else{

menu.innerHTML = `

<a href="login.html" class="add-btn">
Login
</a>

<a href="signup.html" class="add-btn">
Sign Up
</a>

`;

}

}

loadAccountMenu();

if(products.length === 0){

menu.innerHTML=
"<h3>No Products Available</h3>";

return;

}



products.forEach(product=>{


if(product.available){



menu.innerHTML += `


<div class="product-card">


<img src="${product.image || '../images/logo.png'}">


<h3>

${product.name}

</h3>



<p>

${product.description || ""}

</p>



<p>

<del>
Rs.${product.price}

</del>

<br>

<b class="price">

Rs.${product.finalPrice}

</b>


</p>



<button class="add-btn"
onclick="openProduct(${product.id})">

View Item

</button>



</div>


`;



}



});


}



function openProduct(id){


localStorage.setItem(

"selectedProduct",

id

);



window.location.href=

"product.html";


}



showProducts();

function filterCategory(category){


menu.innerHTML="";


let filtered = products.filter(product=>


product.category == category

);



filtered.forEach(product=>{


if(product.available){


menu.innerHTML += `


<div class="product-card">


<img src="${product.image || 'images/logo.png'}">


<h3>
${product.name}
</h3>


<p>
${product.description || ""}
</p>


<p class="price">

Rs.${product.finalPrice}

</p>


<button class="add-btn"
onclick="openProduct(${product.id})">

View Item

</button>


</div>


`;


}


});


}