// Firebase SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyCV1PXkGwJQXxUFx6D4NCQ3oYH68JR4_VQ",
  authDomain: "burgerspot-3a946.firebaseapp.com",
  projectId: "burgerspot-3a946",
  storageBucket: "burgerspot-3a946.firebasestorage.app",
  messagingSenderId: "643202852795",
  appId: "1:643202852795:web:329fad80e3a9015c74069e",
  measurementId: "G-611EJJSBTE"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

import {
  collection,
  addDoc,
  getDocs,
  onSnapshot,
  doc,
  updateDoc
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

export async function saveOrder(order){

await addDoc(
collection(db,"orders"),
order
);

}

export async function saveOrder(order){

await addDoc(
collection(db,"orders"),
order
);

}

localStorage.setItem(
"orders",
JSON.stringify(orders)
);

await saveOrder(order);

import { saveOrder } from "./firebase.js";

