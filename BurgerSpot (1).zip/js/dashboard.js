function displayProducts(){

let products =
JSON.parse(localStorage.getItem("products")) || [];


let burgerList =
document.getElementById("burger-list");


burgerList.innerHTML="";


products.forEach(product=>{


if(product.available){


burgerList.innerHTML += `

<div class="product-card">


<img src="${product.image || 'images/logo.png'}">


<h3>
${product.name}
</h3>


<p>
${product.description}
</p>


<p>
<span style="text-decoration:line-through">
Rs.${product.price}
</span>

<br>

<b>
Rs.${product.finalPrice}
</b>

</p>



<button onclick="openProduct(${product.id})">

View Item

</button>


</div>

`;

}


});


}



function openProduct(id){


localStorage.setItem(
"selectedProduct",
id
);


window.location.href =
"product.html";


}



displayProducts();