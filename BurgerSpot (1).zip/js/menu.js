import {
addDoc,
collection
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";


window.addFavorite = async function(id){

await addDoc(

collection(db,"favorites"),

{

productId: id,

uid: auth.currentUser.uid

}

);


alert("Added to Favorites ⭐");

}
import { auth, db } from "./firebase.js";