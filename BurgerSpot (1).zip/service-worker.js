const cacheName="burgerspot-v1";


self.addEventListener(
"install",
event=>{

event.waitUntil(

caches.open(cacheName)

);

});


self.addEventListener(
"fetch",
event=>{

event.respondWith(

caches.match(event.request)
.then(response=>{

return response || fetch(event.request);

})

);

});

<script>

if("serviceWorker" in navigator){

navigator.serviceWorker.register(
"service-worker.js"
);

}

</script>